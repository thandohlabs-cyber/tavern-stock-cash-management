# Locked business rules
1. Cash balances daily; stock balances by period.
2. Stock Sold Value is generated only when a stock period is completed.
3. Each POS balances independently.
4. Drop to Safe is a transfer, not an expense.
5. Cash Back to Banking is a transfer, not a sale.
6. Multiple card settlements are allowed; pending settlement is not automatically a loss.
7. Expenses are separate from Other Cash Out.
8. Empties are included in Total Stock Sold Value and may have product-specific values.
9. Free stock has zero purchase cost.
10. Historical prices are preserved.
11. Stock adjustments are not automatically sales.
12. Customer exchanges create paired stock movements.
13. Closed periods are locked and reopening is controlled.
14. Sensitive corrections require approval where configured.
15. Audit logs record important changes.
16. Backend calculations are authoritative.
