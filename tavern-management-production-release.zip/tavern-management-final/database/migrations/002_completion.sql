CREATE TABLE IF NOT EXISTS app_settings(
  key text primary key,
  value jsonb not null,
  updated_by uuid references users(id),
  updated_at timestamptz not null default now()
);
CREATE TABLE IF NOT EXISTS numbering_sequences(
  key text primary key,
  prefix text not null,
  next_number bigint not null default 1
);
INSERT INTO app_settings(key,value) VALUES
 ('business', '{"name":"Tavern Stock & Cash Management System","currency":"ZAR","timezone":"Africa/Johannesburg"}'),
 ('stock_period', '{"default_type":"CUSTOM"}'),
 ('approvals', '{"large_stock_adjustment":true,"owner_drawings":true,"stock_count_correction":true,"reopen_pos_day":true,"reopen_stock_period":true,"product_price_change":true,"empty_value_change":true}')
ON CONFLICT (key) DO NOTHING;
INSERT INTO numbering_sequences(key,prefix,next_number) VALUES
 ('stock_receipt','SR',1),('adjustment','ADJ',1),('cash_movement','CM',1),('safe','SAFE',1),('banking','BANK',1),('stock_period','STK',1),('expense','EXP',1),('exchange','EXC',1)
ON CONFLICT (key) DO NOTHING;
