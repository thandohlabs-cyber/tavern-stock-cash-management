INSERT INTO users(name,username,password_hash,role) VALUES('System Administrator','admin',crypt('ChangeMe123!',gen_salt('bf')),'OWNER_ADMIN') ON CONFLICT(username) DO NOTHING;
INSERT INTO product_categories(name) VALUES('Beer'),('Cider'),('Spirits'),('Wine'),('Soft Drinks'),('Water'),('Snacks'),('Other') ON CONFLICT DO NOTHING;
INSERT INTO expense_categories(name) VALUES('Electricity'),('Transport'),('Cleaning'),('Repairs'),('Staff Advance'),('Supplies'),('Bank Charges'),('Other') ON CONFLICT DO NOTHING;
INSERT INTO bank_accounts(bank_name,account_name,account_type,account_number) VALUES('Demo Bank','Tavern Business','Cheque','0000000000') ON CONFLICT DO NOTHING;
INSERT INTO pos_terminals(name,pos_number,provider,location) VALUES('POS 1','POS1','Demo Provider','Counter 1'),('POS 2','POS2','Demo Provider','Counter 2'),('POS 3','POS3','Demo Provider','Counter 3') ON CONFLICT(pos_number) DO NOTHING;
INSERT INTO safes(name,location,opening_balance) VALUES('Main Safe','Office',0) ON CONFLICT DO NOTHING;
