import express, { Request, Response, NextFunction } from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { Pool, PoolClient } from 'pg';

dotenv.config();
const app = express();
const PORT = Number(process.env.PORT || 4000);
const secret = process.env.JWT_SECRET;
if (!secret || secret.length < 32) {
  throw new Error('JWT_SECRET must be set and at least 32 characters long.');
}
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
app.use(cors({ origin: process.env.FRONTEND_URL || 'http://localhost:5173', credentials: true }));
app.use(express.json({ limit: '5mb' }));

type AuthRequest = Request & { user?: any };
const auth = (req: AuthRequest, res: Response, next: NextFunction) => {
  const h = req.headers.authorization || '';
  if (!h.startsWith('Bearer ')) return res.status(401).json({ error: 'Authentication required' });
  try { req.user = jwt.verify(h.slice(7), secret); next(); } catch { return res.status(401).json({ error: 'Invalid or expired session' }); }
};
const role = (...roles: string[]) => (req: AuthRequest, res: Response, next: NextFunction) => roles.includes(req.user?.role) ? next() : res.status(403).json({ error: 'Permission denied' });
const q = async (sql: string, params: any[] = []) => (await pool.query(sql, params)).rows;
const audit = async (client: PoolClient, userId: string, action: string, module: string, recordId: string, reason = '') => {
  await client.query('insert into audit_logs(user_id,action,module,record_id,reason) values($1,$2,$3,$4,$5)', [userId, action, module, recordId, reason]);
};
const today = () => new Date().toISOString().slice(0, 10);

app.get('/api/health', (_req, res) => res.json({ success: true, status: 'healthy', currency: 'ZAR', timezone: 'Africa/Johannesburg' }));

app.post('/api/auth/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    const rows = await q('select id,name,username,password_hash,role,active from users where username=$1', [username]);
    if (!rows.length || !rows[0].active || !(await bcrypt.compare(password || '', rows[0].password_hash))) return res.status(401).json({ error: 'Invalid credentials' });
    const u = rows[0];
    const token = jwt.sign({ id: u.id, name: u.name, username: u.username, role: u.role }, secret, { expiresIn: '8h' });
    res.json({ token, user: { id: u.id, name: u.name, username: u.username, role: u.role } });
  } catch { res.status(500).json({ error: 'Login failed' }); }
});
app.get('/api/me', auth, (req: AuthRequest, res) => res.json(req.user));

app.get('/api/dashboard', auth, async (_req, res) => {
  const [products, pos, openPeriods, pendingBanking, openPos, variance, latest] = await Promise.all([
    q("select count(*)::int count from products where active=true"), q("select count(*)::int count from pos_terminals where active=true"),
    q("select count(*)::int count from stock_periods where status in ('OPEN','BALANCING')"), q("select count(*)::int count from banking_transactions where status<>'CONFIRMED'"),
    q("select count(*)::int count from pos_daily_balances where date=$1 and status<>'CLOSED'", [today()]),
    q("select coalesce(sum(abs(cash_variance)),0)::numeric variance from pos_daily_balances where date=$1", [today()]),
    q("select sp.*, coalesce(sum(ss.total_sold_value),0)::numeric total_sold from stock_periods sp left join stock_sold ss on ss.stock_period_id=sp.id where sp.status in ('BALANCED','CLOSED') group by sp.id order by sp.end_date desc limit 1")
  ]);
  res.json({ products: products[0].count, pos: pos[0].count, openStockPeriods: openPeriods[0].count, pendingBanking: pendingBanking[0].count, openPos: openPos[0].count, todayVariance: Number(variance[0].variance), latestStockPeriod: latest[0] || null });
});

app.get('/api/users', auth, role('OWNER_ADMIN'), async (_req, res) => res.json(await q('select id,name,username,role,active,created_at from users order by name')));
app.post('/api/users', auth, role('OWNER_ADMIN'), async (req: AuthRequest, res) => {
  const { name, username, password, role: userRole, active = true } = req.body;
  if (!name || !username || !password || !['OWNER_ADMIN','MANAGER','CASHIER'].includes(userRole)) return res.status(400).json({ error: 'Invalid user data' });
  const hash = await bcrypt.hash(password, 12);
  const rows = await q('insert into users(name,username,password_hash,role,active) values($1,$2,$3,$4,$5) returning id,name,username,role,active', [name, username, hash, userRole, active]);
  res.status(201).json(rows[0]);
});

app.get('/api/products', auth, async (_req, res) => res.json(await q('select p.*, pc.name category from products p left join product_categories pc on pc.id=p.category_id where p.active=true order by p.name')));
app.post('/api/products', auth, role('OWNER_ADMIN','MANAGER'), async (req: AuthRequest, res) => {
  const { sku, name, category_id, case_size, pack_size, returnable_empty=false, empty_type, empty_value=0 } = req.body;
  if (!sku || !name || !Number(case_size) || !Number(pack_size)) return res.status(400).json({ error: 'SKU, name, case size and pack size are required' });
  const rows = await q('insert into products(sku,name,category_id,case_size,pack_size,returnable_empty,empty_type,empty_value) values($1,$2,$3,$4,$5,$6,$7,$8,$9) returning *', [sku,name,category_id||null,case_size,pack_size,returnable_empty,empty_type||null,empty_value]);
  res.status(201).json(rows[0]);
});
app.post('/api/products/:id/prices', auth, role('OWNER_ADMIN','MANAGER'), async (req: AuthRequest, res) => {
  const { price_type, unit, price, effective_from } = req.body;
  const rows = await q('insert into product_prices(product_id,price_type,unit,price,effective_from,changed_by) values($1,$2,$3,$4,$5,$6) returning *',[req.params.id,price_type,unit,price,effective_from||today(),req.user.id]);
  res.status(201).json(rows[0]);
});
app.get('/api/categories', auth, async (_req,res)=>res.json(await q('select * from product_categories where active=true order by name')));
app.get('/api/suppliers', auth, async (_req,res)=>res.json(await q('select * from suppliers where active=true order by name')));
app.post('/api/suppliers', auth, role('OWNER_ADMIN','MANAGER'), async(req,res)=>{const {name,code,contact,phone,email,address,terms}=req.body;res.status(201).json((await q('insert into suppliers(name,code,contact,phone,email,address,terms) values($1,$2,$3,$4,$5,$6,$7) returning *',[name,code||null,contact||null,phone||null,email||null,address||null,terms||null]))[0]);});
app.get('/api/pos', auth, async (_req,res)=>res.json(await q('select p.*, b.bank_name from pos_terminals p left join bank_accounts b on b.id=p.bank_account_id where p.active=true order by p.pos_number')));

app.get('/api/stock-receipts', auth, async (_req,res)=>res.json(await q(`select sr.*,s.name supplier,u.name receiver from stock_receipts sr left join suppliers s on s.id=sr.supplier_id left join users u on u.id=sr.received_by order by receipt_date desc,created_at desc`)));
app.post('/api/stock-receipts', auth, role('OWNER_ADMIN','MANAGER'), async(req:AuthRequest,res)=>{
  const client=await pool.connect(); try { await client.query('begin');
    const {receipt_number,receipt_date=today(),supplier_id,invoice_number,delivery_note,notes,lines=[]}=req.body;
    const r=(await client.query('insert into stock_receipts(receipt_number,receipt_date,supplier_id,invoice_number,delivery_note,received_by,notes,status) values($1,$2,$3,$4,$5,$6,$7,$8) returning *',[receipt_number||`SR-${Date.now()}`,receipt_date,supplier_id||null,invoice_number||null,delivery_note||null,req.user.id,notes||null,'POSTED'])).rows[0];
    for(const l of lines){ const totalSingles=Number(l.cases||0)*Number(l.case_size||0)+Number(l.packs||0)*Number(l.pack_size||0)+Number(l.singles||0); const freeSingles=Number(l.free_cases||0)*Number(l.case_size||0)+Number(l.free_packs||0)*Number(l.pack_size||0)+Number(l.free_singles||0); const totalCost=Number(l.cases||0)*Number(l.buying_price_case||0)+Number(l.packs||0)*Number(l.buying_price_pack||0)+Number(l.singles||0)*Number(l.buying_price_single||0); await client.query('insert into stock_receipt_lines(receipt_id,product_id,cases,packs,singles,free_cases,free_packs,free_singles,buying_price_case,buying_price_pack,buying_price_single,total_cost) values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)',[r.id,l.product_id,l.cases||0,l.packs||0,l.singles||0,l.free_cases||0,l.free_packs||0,l.free_singles||0,l.buying_price_case||0,l.buying_price_pack||0,l.buying_price_single||0,totalCost]); }
    await audit(client,req.user.id,'CREATE','STOCK_RECEIPT',r.id); await client.query('commit'); res.status(201).json(r);
  } catch(e){await client.query('rollback');res.status(400).json({error:(e as Error).message})}finally{client.release()}
});

app.get('/api/stock-adjustments', auth, async (_req,res)=>res.json(await q(`select a.*,p.name product_name from stock_adjustments a left join products p on p.id=a.product_id order by a.date desc,a.created_at desc`)));
app.post('/api/stock-adjustments', auth, async(req:AuthRequest,res)=>{const b=req.body;const sensitive=['OWNER_DRAWINGS','STOCK_COUNT_CORRECTION'];const approval=sensitive.includes(b.adjustment_type)?'PENDING':'NOT_REQUIRED';const r=(await q('insert into stock_adjustments(adjustment_number,date,product_id,adjustment_type,direction,quantity,unit,reason,notes,created_by,approval_status) values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) returning *',[b.adjustment_number||`ADJ-${Date.now()}`,b.date||today(),b.product_id,b.adjustment_type,b.direction,b.quantity,b.unit||'SINGLE',b.reason,b.notes||null,req.user.id,approval]))[0];res.status(201).json(r)});
app.get('/api/stock-periods', auth, async (_req,res)=>res.json(await q('select sp.*,u.name creator from stock_periods sp left join users u on u.id=sp.created_by order by start_date desc')));
app.post('/api/stock-periods', auth, role('OWNER_ADMIN','MANAGER'), async(req:AuthRequest,res)=>{const {period_number,start_date,end_date}=req.body; if(!period_number||!start_date||!end_date)return res.status(400).json({error:'Period number and dates are required'}); const r=(await q('insert into stock_periods(period_number,start_date,end_date,created_by,status) values($1,$2,$3,$4,\'OPEN\') returning *',[period_number,start_date,end_date,req.user.id]))[0]; const products=await q('select id from products where active=true'); for(const p of products) await q('insert into stock_balances(stock_period_id,product_id) values($1,$2) on conflict do nothing',[r.id,p.id]); res.status(201).json(r)});
app.get('/api/stock-periods/:id', auth, async(req,res)=>{
  const p=(await q('select * from stock_periods where id=$1',[req.params.id]))[0];
  if(!p)return res.status(404).json({error:'Period not found'});
  const balances=await q(`
    select sb.*,p.sku,p.name,p.case_size,p.pack_size,p.empty_value,p.returnable_empty,
      coalesce((select sum((l.cases*p.case_size)+(l.packs*p.pack_size)+l.singles)
        from stock_receipt_lines l join stock_receipts r on r.id=l.receipt_id
        where l.product_id=p.id and r.status='POSTED' and r.receipt_date between $2 and $3),0) stock_received_computed,
      coalesce((select sum(case when a.direction='IN' then a.quantity*p.case_size else 0 end)
        from stock_adjustments a where a.product_id=p.id and a.direction='IN' and a.approval_status<>'PENDING' and a.date between $2 and $3),0)
      +coalesce((select sum(case when a.direction='CORRECTION' and a.quantity>0 then a.quantity*p.case_size else 0 end)
        from stock_adjustments a where a.product_id=p.id and a.approval_status<>'PENDING' and a.date between $2 and $3),0) stock_in_adjustments_computed,
      coalesce((select sum(case when a.direction='OUT' then a.quantity*p.case_size else 0 end)
        from stock_adjustments a where a.product_id=p.id and a.direction='OUT' and a.approval_status<>'PENDING' and a.date between $2 and $3),0)
      +coalesce((select sum(case when a.direction='CORRECTION' and a.quantity<0 then abs(a.quantity)*p.case_size else 0 end)
        from stock_adjustments a where a.product_id=p.id and a.approval_status<>'PENDING' and a.date between $2 and $3),0) stock_out_adjustments_computed
    from stock_balances sb join products p on p.id=sb.product_id
    where sb.stock_period_id=$1 order by p.name`,[req.params.id,p.start_date,p.end_date]);
  res.json({period:p,balances});
});

app.put('/api/stock-periods/:id/balances', auth, role('OWNER_ADMIN','MANAGER'), async(req,res)=>{
  const {balances=[]}=req.body; const client=await pool.connect();
  try{await client.query('begin');
    const period=(await client.query('select * from stock_periods where id=$1 for update',[req.params.id])).rows[0];
    if(!period) throw new Error('Period not found'); if(period.status==='CLOSED'||period.status==='BALANCED') throw new Error('Period is locked');
    for(const b of balances) await client.query('update stock_balances set opening_stock=$1,stock_sold=$2,physical_closing=$3 where id=$4 and stock_period_id=$5',[b.opening_stock||0,b.stock_sold||0,b.physical_closing||0,b.id,req.params.id]);
    await client.query("update stock_periods set status='BALANCING' where id=$1 and status='OPEN'",[req.params.id]);
    await client.query('commit');res.json({success:true});
  }catch(e){await client.query('rollback');res.status(400).json({error:(e as Error).message})}finally{client.release()}
});

app.post('/api/stock-periods/:id/complete', auth, role('OWNER_ADMIN','MANAGER'), async(req:AuthRequest,res)=>{
  const client=await pool.connect();
  try{await client.query('begin');
    const p=(await client.query('select * from stock_periods where id=$1 for update',[req.params.id])).rows[0];
    if(!p)throw new Error('Period not found'); if(p.status==='CLOSED')throw new Error('Period is locked');
    const balances=(await client.query(`
      select sb.*,p.case_size,p.pack_size,p.empty_value,p.returnable_empty,
        coalesce((select sum((l.cases*p.case_size)+(l.packs*p.pack_size)+l.singles)
          from stock_receipt_lines l join stock_receipts r on r.id=l.receipt_id
          where l.product_id=p.id and r.status='POSTED' and r.receipt_date between $2 and $3),0) received,
        coalesce((select sum(case when a.direction='IN' then a.quantity*p.case_size when a.direction='CORRECTION' and a.quantity>0 then a.quantity*p.case_size else 0 end)
          from stock_adjustments a where a.product_id=p.id and a.approval_status<>'PENDING' and a.date between $2 and $3),0) stock_in,
        coalesce((select sum(case when a.direction='OUT' then a.quantity*p.case_size when a.direction='CORRECTION' and a.quantity<0 then abs(a.quantity)*p.case_size else 0 end)
          from stock_adjustments a where a.product_id=p.id and a.approval_status<>'PENDING' and a.date between $2 and $3),0) stock_out
      from stock_balances sb join products p on p.id=sb.product_id where sb.stock_period_id=$1`,[p.id,p.start_date,p.end_date])).rows;
    let total=0;
    for(const x of balances){
      const opening=Number(x.opening_stock||0), received=Number(x.received||0), stockIn=Number(x.stock_in||0), sold=Number(x.stock_sold||0), stockOut=Number(x.stock_out||0);
      const expected=opening+received+stockIn-sold-stockOut;
      await client.query('update stock_balances set stock_received=$1,stock_in_adjustments=$2,stock_out_adjustments=$3,expected_closing=$4,variance=physical_closing-$4 where id=$5',[received,stockIn,stockOut,expected,x.id]);
      const casePrice=Number((await client.query("select price from product_prices where product_id=$1 and price_type='SELLING' and unit='CASE' and effective_from <= $2 and (effective_to is null or effective_to >= $2) order by effective_from desc limit 1",[x.product_id,p.end_date])).rows[0]?.price||0);
      const packPrice=Number((await client.query("select price from product_prices where product_id=$1 and price_type='SELLING' and unit='PACK' and effective_from <= $2 and (effective_to is null or effective_to >= $2) order by effective_from desc limit 1",[x.product_id,p.end_date])).rows[0]?.price||0);
      const singlePrice=Number((await client.query("select price from product_prices where product_id=$1 and price_type='SELLING' and unit='SINGLE' and effective_from <= $2 and (effective_to is null or effective_to >= $2) order by effective_from desc limit 1",[x.product_id,p.end_date])).rows[0]?.price||0);
      const cases=Math.floor(sold/Number(x.case_size)), rem=sold-cases*Number(x.case_size), packs=Math.floor(rem/Number(x.pack_size)), singles=rem-packs*Number(x.pack_size);
      const productValue=cases*casePrice+packs*packPrice+singles*singlePrice, emptyQty=x.returnable_empty?sold:0, emptyValue=emptyQty*Number(x.empty_value||0);
      await client.query('delete from stock_sold where stock_period_id=$1 and product_id=$2',[p.id,x.product_id]);
      await client.query('insert into stock_sold(stock_period_id,product_id,cases_sold,packs_sold,singles_sold,total_singles,product_stock_sold_value,empty_quantity,empty_value,total_sold_value) values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10)',[p.id,x.product_id,cases,packs,singles,sold,productValue,emptyQty,emptyValue,productValue+emptyValue]);
      total+=productValue+emptyValue;
    }
    await client.query("update stock_periods set status='BALANCED',balanced_by=$1,completed_at=now() where id=$2",[req.user.id,p.id]);
    await audit(client,req.user.id,'COMPLETE','STOCK_PERIOD',p.id,'Stock period completed');
    await client.query('commit');res.json({success:true,totalStockSoldValue:total,status:'BALANCED'});
  }catch(e){await client.query('rollback');res.status(400).json({error:(e as Error).message})}finally{client.release()}
});

app.post('/api/stock-periods/:id/close', auth, role('OWNER_ADMIN'), async(req:AuthRequest,res)=>{const client=await pool.connect();try{await client.query('begin');await client.query("update stock_periods set status='CLOSED',closed_by=$1,closed_at=now() where id=$2 and status='BALANCED'",[req.user.id,req.params.id]);await audit(client,req.user.id,'CLOSE','STOCK_PERIOD',req.params.id,req.body.reason||'Period closed');await client.query('commit');res.json({success:true})}catch(e){await client.query('rollback');res.status(400).json({error:(e as Error).message})}finally{client.release()}});

app.get('/api/pos-daily', auth, async(req,res)=>res.json(await q(`select d.*,p.name pos_name,p.pos_number from pos_daily_balances d join pos_terminals p on p.id=d.pos_id where d.date=$1 order by p.pos_number`,[req.query.date||today()])));
app.post('/api/pos-daily', auth, async(req:AuthRequest,res)=>{const b=req.body;const expected=Number(b.opening_cash||0)+Number(b.cash_sales||0)+Number(b.other_cash_in||0)-Number(b.other_cash_out||0)-Number(b.expenses||0);const variance=Number(b.actual_closing||0)-expected;const cashRemaining=Number(b.actual_closing||0)-Number(b.drop_to_safe||0)-Number(b.cash_back||0);const settlements=Number(b.card_settlements||0);const cardVariance=Number(b.card_sales||0)-settlements;const r=await q(`insert into pos_daily_balances(date,pos_id,opening_cash,cash_sales,other_cash_in,other_cash_out,expenses,expected_closing,actual_closing,cash_variance,drop_to_safe,cash_back,cash_remaining,card_sales,card_settlements,card_variance,status,opened_by) values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,'OPEN',$17) on conflict(date,pos_id) do update set opening_cash=excluded.opening_cash,cash_sales=excluded.cash_sales,other_cash_in=excluded.other_cash_in,other_cash_out=excluded.other_cash_out,expenses=excluded.expenses,expected_closing=excluded.expected_closing,actual_closing=excluded.actual_closing,cash_variance=excluded.cash_variance,drop_to_safe=excluded.drop_to_safe,cash_back=excluded.cash_back,cash_remaining=excluded.cash_remaining,card_sales=excluded.card_sales,card_settlements=excluded.card_settlements,card_variance=excluded.card_variance returning *`,[b.date||today(),b.pos_id,b.opening_cash||0,b.cash_sales||0,b.other_cash_in||0,b.other_cash_out||0,b.expenses||0,expected,b.actual_closing||0,variance,b.drop_to_safe||0,b.cash_back||0,cashRemaining,b.card_sales||0,settlements,cardVariance,req.user.id]);res.json(r[0])});
app.post('/api/pos-daily/:id/close',auth,async(req:AuthRequest,res)=>{const r=(await q("update pos_daily_balances set status='CLOSED',closed_by=$1,closed_at=now() where id=$2 and status<>'CLOSED' returning *",[req.user.id,req.params.id]))[0];if(!r)return res.status(400).json({error:'Day not found or already closed'});res.json(r)});
app.get('/api/cash-movements',auth,async(req,res)=>res.json(await q('select cm.*,p.name pos_name from cash_movements cm left join pos_terminals p on p.id=cm.pos_id where date between $1 and $2 order by date desc,created_at desc',[req.query.from||'1900-01-01',req.query.to||'2999-12-31'])));
app.post('/api/cash-movements',auth,async(req:AuthRequest,res)=>{const b=req.body;const r=(await q('insert into cash_movements(movement_number,date,pos_id,type,description,amount,user_id,notes) values($1,$2,$3,$4,$5,$6,$7,$8) returning *',[b.movement_number||`CM-${Date.now()}`,b.date||today(),b.pos_id,b.type,b.description,b.amount,req.user.id,b.notes||null]))[0];res.status(201).json(r)});
app.get('/api/expenses',auth,async(req,res)=>res.json(await q('select e.*,p.name pos_name,ec.name category from expenses e left join pos_terminals p on p.id=e.pos_id left join expense_categories ec on ec.id=e.expense_category_id where e.date between $1 and $2 order by e.date desc,e.created_at desc',[req.query.from||'1900-01-01',req.query.to||'2999-12-31'])));
app.post('/api/expenses',auth,async(req:AuthRequest,res)=>{const b=req.body;const r=(await q('insert into expenses(expense_number,date,pos_id,expense_category_id,description,amount,payment_method,user_id,notes) values($1,$2,$3,$4,$5,$6,$7,$8,$9) returning *',[b.expense_number||`EXP-${Date.now()}`,b.date||today(),b.pos_id,b.expense_category_id||null,b.description,b.amount,b.payment_method||'CASH',req.user.id,b.notes||null]))[0];res.status(201).json(r)});
app.get('/api/safes',auth,async(_req,res)=>res.json(await q('select * from safes where active=true order by name')));
app.get('/api/safe-movements',auth,async(req,res)=>res.json(await q('select sm.*,s.name safe_name from safe_movements sm join safes s on s.id=sm.safe_id where sm.date between $1 and $2 order by sm.date desc,sm.created_at desc',[req.query.from||'1900-01-01',req.query.to||'2999-12-31'])));
app.post('/api/safe-movements',auth,async(req:AuthRequest,res)=>{const b=req.body;const r=(await q('insert into safe_movements(movement_number,date,safe_id,pos_id,movement_type,amount,user_id,witness,reference,notes) values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) returning *',[b.movement_number||`SAFE-${Date.now()}`,b.date||today(),b.safe_id,b.pos_id||null,b.movement_type,b.amount,req.user.id,b.witness||null,b.reference||null,b.notes||null]))[0];res.status(201).json(r)});
app.get('/api/banking',auth,async(req,res)=>res.json(await q('select bt.*,p.name pos_name,b.bank_name,b.account_name from banking_transactions bt left join pos_terminals p on p.id=bt.pos_id left join bank_accounts b on b.id=bt.bank_account_id where bt.date between $1 and $2 order by bt.date desc,bt.created_at desc',[req.query.from||'1900-01-01',req.query.to||'2999-12-31'])));
app.post('/api/banking',auth,async(req:AuthRequest,res)=>{const b=req.body;const r=(await q('insert into banking_transactions(banking_number,date,pos_id,banking_type,amount,bank_account_id,reference,banked_by,notes,status) values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) returning *',[b.banking_number||`BANK-${Date.now()}`,b.date||today(),b.pos_id||null,b.banking_type,b.amount,b.bank_account_id,b.reference||null,req.user.id,b.notes||null,b.status||'PENDING']))[0];res.status(201).json(r)});
app.patch('/api/banking/:id/status',auth,async(req,res)=>{const r=(await q('update banking_transactions set status=$1,updated_at=now() where id=$2 returning *',[req.body.status,req.params.id]))[0];res.json(r)});
app.get('/api/card-settlements',auth,async(req,res)=>res.json(await q('select cs.*,p.name pos_name from card_settlements cs left join pos_terminals p on p.id=cs.pos_id where cs.date between $1 and $2 order by cs.date desc',[req.query.from||'1900-01-01',req.query.to||'2999-12-31'])));
app.post('/api/card-settlements',auth,async(req:AuthRequest,res)=>{const b=req.body;const r=(await q('insert into card_settlements(date,pos_id,settlement_reference,amount,bank_account_id,settlement_date,status,created_by) values($1,$2,$3,$4,$5,$6,$7,$8) returning *',[b.date||today(),b.pos_id,b.settlement_reference,b.amount,b.bank_account_id||null,b.settlement_date||today(),b.status||'PENDING',req.user.id]))[0];res.status(201).json(r)});

app.get('/api/reconciliation/:periodId',auth,async(req,res)=>{const p=(await q('select sp.*,coalesce(sum(ss.total_sold_value),0)::numeric stock_sold_value from stock_periods sp left join stock_sold ss on ss.stock_period_id=sp.id where sp.id=$1 group by sp.id',[req.params.periodId]))[0];if(!p)return res.status(404).json({error:'Period not found'});const cash=(await q('select coalesce(sum(cash_sales),0)::numeric v from pos_daily_balances where date between $1 and $2',[p.start_date,p.end_date]))[0].v;const card=(await q('select coalesce(sum(card_sales),0)::numeric v from pos_daily_balances where date between $1 and $2',[p.start_date,p.end_date]))[0].v;const other=(await q("select coalesce(sum(case when type='CASH_IN' then amount else 0 end),0)::numeric v from cash_movements where date between $1 and $2",[p.start_date,p.end_date]))[0].v;const total=Number(cash)+Number(card)+Number(other);const difference=Number(total)-Number(p.stock_sold_value);res.json({period:p,cashAccounted:Number(cash),cardAccounted:Number(card),otherAccounted:Number(other),totalAccounted:total,difference,status:Math.abs(difference)<0.01?'RECONCILED':'DIFFERENCE'});});
app.get('/api/reports/summary',auth,async(req,res)=>{const from=req.query.from||'1900-01-01',to=req.query.to||'2999-12-31';const [purchases,sales,expenses,banking]=await Promise.all([q('select coalesce(sum(total_cost),0)::numeric v from stock_receipt_lines l join stock_receipts r on r.id=l.receipt_id where r.receipt_date between $1 and $2',[from,to]),q('select coalesce(sum(total_sold_value),0)::numeric v from stock_sold ss join stock_periods sp on sp.id=ss.stock_period_id where sp.end_date between $1 and $2',[from,to]),q('select coalesce(sum(amount),0)::numeric v from expenses where date between $1 and $2',[from,to]),q('select coalesce(sum(amount),0)::numeric v from banking_transactions where date between $1 and $2 and status in (\'BANKED\',\'CONFIRMED\')',[from,to])]);res.json({purchaseCost:Number(purchases[0].v),salesValue:Number(sales[0].v),expenses:Number(expenses[0].v),banked:Number(banking[0].v),grossProfit:Number(sales[0].v)-Number(purchases[0].v)});});
app.get('/api/settings',auth,async(_req,res)=>res.json(await q('select key,value,updated_at from app_settings order by key')));
app.put('/api/settings/:key',auth,role('OWNER_ADMIN'),async(req:AuthRequest,res)=>{
  const key=req.params.key; const value=req.body.value;
  if(value===undefined)return res.status(400).json({error:'value is required'});
  const r=(await q('insert into app_settings(key,value,updated_by) values($1,$2,$3) on conflict(key) do update set value=excluded.value,updated_by=excluded.updated_by,updated_at=now() returning *',[key,JSON.stringify(value),req.user.id]))[0];
  res.json(r);
});
app.get('/api/bank-accounts',auth,async(_req,res)=>res.json(await q('select id,bank_name,account_name,account_type,account_number,branch,active from bank_accounts order by bank_name,account_name')));
app.post('/api/bank-accounts',auth,role('OWNER_ADMIN','MANAGER'),async(req,res)=>{const b=req.body;const r=(await q('insert into bank_accounts(bank_name,account_name,account_type,account_number,branch) values($1,$2,$3,$4,$5) returning *',[b.bank_name,b.account_name,b.account_type||null,b.account_number||null,b.branch||null]))[0];res.status(201).json(r)});
app.post('/api/pos',auth,role('OWNER_ADMIN'),async(req,res)=>{const b=req.body;const r=(await q('insert into pos_terminals(name,pos_number,provider,terminal_id,bank_account_id,location) values($1,$2,$3,$4,$5,$6) returning *',[b.name,b.pos_number,b.provider||null,b.terminal_id||null,b.bank_account_id||null,b.location||null]))[0];res.status(201).json(r)});
app.post('/api/safes',auth,role('OWNER_ADMIN'),async(req,res)=>{const b=req.body;const r=(await q('insert into safes(name,location,opening_balance) values($1,$2,$3) returning *',[b.name,b.location||null,b.opening_balance||0]))[0];res.status(201).json(r)});
app.post('/api/exchanges',auth,async(req:AuthRequest,res)=>{
  const b=req.body; const client=await pool.connect();
  try{await client.query('begin');
    const ex=(await client.query('insert into customer_exchanges(exchange_number,date,returned_product_id,returned_cases,returned_packs,returned_singles,replacement_product_id,replacement_cases,replacement_packs,replacement_singles,price_difference,price_difference_direction,reason,notes,created_by) values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15) returning *',[b.exchange_number||`EXC-${Date.now()}`,b.date||today(),b.returned_product_id,b.returned_cases||0,b.returned_packs||0,b.returned_singles||0,b.replacement_product_id,b.replacement_cases||0,b.replacement_packs||0,b.replacement_singles||0,b.price_difference||0,b.price_difference_direction||'NONE',b.reason,b.notes||null,req.user.id])).rows[0];
    await audit(client,req.user.id,'CREATE','CUSTOMER_EXCHANGE',ex.id,'Customer exchange recorded'); await client.query('commit'); res.status(201).json(ex);
  }catch(e){await client.query('rollback');res.status(400).json({error:(e as Error).message})}finally{client.release()}
});
app.get('/api/exchanges',auth,async(_req,res)=>res.json(await q(`select e.*,rp.name returned_product,sp.name replacement_product from customer_exchanges e left join products rp on rp.id=e.returned_product_id left join products sp on sp.id=e.replacement_product_id order by e.date desc,e.created_at desc`)));

app.get('/api/reports/:report.csv',auth,async(req,res)=>{
  const from=String(req.query.from||'1900-01-01'), to=String(req.query.to||'2999-12-31'), name=String(req.params.report);
  let sql='select * from expenses where date between $1 and $2 order by date'; let headers=['id','date','description','amount'];
  if(name==='daily-cash') { sql=`select d.date,p.pos_number,p.name as pos_name,d.opening_cash,d.cash_sales,d.other_cash_in,d.other_cash_out,d.expenses,d.expected_closing,d.actual_closing,d.cash_variance,d.drop_to_safe,d.cash_back,d.card_sales,d.card_settlements,d.card_variance,d.status from pos_daily_balances d join pos_terminals p on p.id=d.pos_id where d.date between $1 and $2 order by d.date,p.pos_number`; headers=['date','pos_number','pos_name','opening_cash','cash_sales','other_cash_in','other_cash_out','expenses','expected_closing','actual_closing','cash_variance','drop_to_safe','cash_back','card_sales','card_settlements','card_variance','status']; }
  else if(name==='stock-purchase') { sql=`select r.receipt_date,r.receipt_number,s.name supplier,p.sku,p.name product,l.cases,l.packs,l.singles,l.free_cases,l.free_packs,l.free_singles,l.buying_price_case,l.buying_price_pack,l.buying_price_single,l.total_cost from stock_receipt_lines l join stock_receipts r on r.id=l.receipt_id left join suppliers s on s.id=r.supplier_id join products p on p.id=l.product_id where r.receipt_date between $1 and $2 order by r.receipt_date,r.receipt_number`; headers=['receipt_date','receipt_number','supplier','sku','product','cases','packs','singles','free_cases','free_packs','free_singles','buying_price_case','buying_price_pack','buying_price_single','total_cost']; }
  else if(name==='stock-sold') { sql=`select sp.period_number,sp.start_date,sp.end_date,p.sku,p.name product,ss.cases_sold,ss.packs_sold,ss.singles_sold,ss.total_singles,ss.product_stock_sold_value,ss.empty_quantity,ss.empty_value,ss.total_sold_value from stock_sold ss join stock_periods sp on sp.id=ss.stock_period_id join products p on p.id=ss.product_id where sp.end_date between $1 and $2 order by sp.end_date,p.name`; headers=['period_number','start_date','end_date','sku','product','cases_sold','packs_sold','singles_sold','total_singles','product_stock_sold_value','empty_quantity','empty_value','total_sold_value']; }
  else if(name==='banking') { sql=`select bt.date,bt.banking_number,bt.banking_type,bt.amount,b.bank_name,b.account_name,bt.reference,bt.status from banking_transactions bt left join bank_accounts b on b.id=bt.bank_account_id where bt.date between $1 and $2 order by bt.date`; headers=['date','banking_number','banking_type','amount','bank_name','account_name','reference','status']; }
  else if(name==='expenses') { headers=['date','expense_number','pos_name','category','description','amount','payment_method']; sql=`select e.date,e.expense_number,p.name pos_name,ec.name category,e.description,e.amount,e.payment_method from expenses e left join pos_terminals p on p.id=e.pos_id left join expense_categories ec on ec.id=e.expense_category_id where e.date between $1 and $2 order by e.date`; }
  else if(name==='empties') { headers=['date','product','movement_type','quantity','empty_value','reference']; sql=`select em.date,p.name product,em.movement_type,em.quantity,em.empty_value,em.reference from empty_movements em left join products p on p.id=em.product_id where em.date between $1 and $2 order by em.date`; }
  const rows=await q(sql,[from,to]); const esc=(v:any)=>`"${String(v??'').replace(/"/g,'""')}"`; const csv=[headers.join(','),...rows.map((r:any)=>headers.map(h=>esc(r[h])).join(','))].join('\n');
  res.setHeader('Content-Type','text/csv; charset=utf-8'); res.setHeader('Content-Disposition',`attachment; filename="${name}-${from}-${to}.csv"`); res.send(csv);
});

app.get('/api/audit',auth,role('OWNER_ADMIN','MANAGER'),async(_req,res)=>res.json(await q('select a.*,u.name user_name from audit_logs a left join users u on u.id=a.user_id order by a.created_at desc limit 500')));

app.use((err:any,_req:Request,res:Response,_next:NextFunction)=>{console.error(err);res.status(500).json({error:'Unexpected server error'});});
app.listen(PORT,()=>console.log(`Tavern API running on http://localhost:${PORT}`));
